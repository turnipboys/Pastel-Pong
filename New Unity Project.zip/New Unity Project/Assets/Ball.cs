﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Ball : MonoBehaviour {
    public float speed = 30;
    public Vector2 angle = Vector2.right;
    //score
    public Text rightScoreDisplay;
    public Text leftScoreDisplay;

    private int rightScore = 0;
    private int leftScore = 0;
    //timing
    private float timePassed = 0;
    private float startSpeed;
    private bool speedUp = true;

	// Use this for initialization
	void Start () {
        startSpeed = speed;
        speed /= 10;
        GetComponent<Rigidbody2D>().velocity = angle.normalized * speed;
	}

    private void Update()
    {
        timePassed += Time.deltaTime;
        if(timePassed > 1 && speedUp)
        {
            speed = startSpeed;
            Vector2 currentVelocity = GetComponent<Rigidbody2D>().velocity;
            GetComponent<Rigidbody2D>().velocity = currentVelocity.normalized * speed;
            speedUp = false;
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.name == "wall_left")
        {
            rightScoreDisplay.text = "" + ++rightScore;
            transform.position = Vector3.zero;
            speed /= 10;
            timePassed = 0;
            speedUp = true;
            GetComponent<Rigidbody2D>().velocity = angle.normalized * speed;
            //this increases right score & resets ball
        }
        if (collision.gameObject.name == "wall_right")
        {
            leftScoreDisplay.text = "" + ++leftScore;
            transform.position = Vector3.zero;
            speed /= 10;
            timePassed = 0;
            speedUp = true;
            GetComponent<Rigidbody2D>().velocity = -angle.normalized * speed;
            //this increases left score & resets ball
        }
        if (collision.gameObject.name == "paddle_left")
        {
            //changing direction of ball
            float ballY = transform.position.y;
            float paddleY = collision.gameObject.transform.position.y;
            float paddleHeight = collision.collider.bounds.size.y;
            float y_velocity = (ballY - paddleY) / (paddleHeight / 2);
            GetComponent<Rigidbody2D>().velocity = new Vector2(1, y_velocity).normalized * speed;
        }
        if (collision.gameObject.name == "paddle_right")
        {
            //changing direction of ball
            float ballY = transform.position.y;
            float paddleY = collision.gameObject.transform.position.y;
            float paddleHeight = collision.collider.bounds.size.y;
            float y_velocity = (ballY - paddleY) / (paddleHeight / 2);
            GetComponent<Rigidbody2D>().velocity = new Vector2(-1, y_velocity).normalized * speed;
        }
    }
    
}
